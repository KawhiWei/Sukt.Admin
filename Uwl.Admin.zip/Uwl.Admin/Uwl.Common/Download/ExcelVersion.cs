﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uwl.Common.Download
{
    public enum ExcelVersion
    {
        xls,
        xlsx
    }
}
