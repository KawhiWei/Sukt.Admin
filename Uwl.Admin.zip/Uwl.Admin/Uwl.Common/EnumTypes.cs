﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uwl.Common
{
    public enum EnumTypes
    {
        用户登录,
        菜单权限,
        权限菜单,
        系统管理,
        个人中心,
        其他分类,
    }
}
