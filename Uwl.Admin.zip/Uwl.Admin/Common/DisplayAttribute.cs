﻿using System;

namespace Uwl.Utility.Common
{
    internal class DisplayAttribute : Attribute
    {
        public string Name;
    }
}