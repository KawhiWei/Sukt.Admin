﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uwl.QuartzNet.JobCenter.Tools
{
    /// <summary>
    /// 定时任务执行时间监听工具
    /// </summary>
    public class PerformanceTool
    {
        public PerformanceTool()
        {

        }
        /// <summary>
        /// 记录执行日志
        /// </summary>
        public static void SetLog()
        {

        }


    }
}
