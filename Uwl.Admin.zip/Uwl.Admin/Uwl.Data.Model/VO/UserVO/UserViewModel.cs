﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uwl.Data.Model.VO.UserVO
{
    public class UserViewModel
    {

    }
}
