﻿using System;
using System.Collections.Generic;
using System.Text;
using Uwl.Data.Model.BaseModel;
using Uwl.Domain.IRepositories;

namespace Uwl.Domain.RoleInterface
{
    public interface IRoleRepositoty : IRepository<SysRole>
    {

    }
}
