﻿using System;
using System.Collections.Generic;
using System.Text;
using Uwl.Data.Model.BaseModel;
using Uwl.Domain.IRepositories;

namespace Uwl.Domain.MenuInterface
{
    public interface ISysMenuButton : IRepository<SysMenuButton>
    {
    }
}
